For learning the parameters of facial landmark detector run script flandmark_learn.m

Please note, that this script assumes symbolic link ../LFW pointing to
the directory containing the LFW database (for download link please visit the
flandmark homepage: http://cmp.felk.cvut.cz/~uricamic/flandmark )
